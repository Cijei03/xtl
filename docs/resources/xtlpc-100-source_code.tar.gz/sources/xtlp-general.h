#pragma once
#include <stdint.h>
#include <stddef.h>

char* const xtlpMakeContextString(char** C, const uint32_t count);

size_t conlen(char** C);